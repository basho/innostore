/***********************************************************************
Copyright (c) 2008 Innobase Oy. All rights reserved.
Copyright (c) 2008 Oracle. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

************************************************************************/
#include <stdarg.h>

#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif

#include "univ.i"
#include "api0api.h"
#include "btr0sea.h"
#include "db0err.h"
#include "log0recv.h"
#include "srv0srv.h"
#include "srv0start.h"
#include "trx0sys.h" /* for trx_sys_file_format_name_to_id() */
#include "ut0mem.h" /* for ut_malloc() */

/* If set then we rollback the transaction on DB_LOCK_WAIT_TIMEOUT error. */
extern ibool	ses_rollback_on_timeout;

typedef enum ib_cfg_flag {
	IB_CFG_FLAG_NONE = 0x1,
	IB_CFG_FLAG_READONLY_AFTER_STARTUP = 0x2,/* can be modified only
						 before innodb is started */
	IB_CFG_FLAG_READONLY = 0x4,		/* cannot be modified */
	IB_CFG_FLAG_TANK_IS_ALLOCD = 0x8	/* the memory pointed by the
						::tank member has been
						allocated with ut_malloc() and
						should be freed if a new one is
						to be assigned */
} ib_cfg_flag_t;

typedef struct ib_cfg_var {
	const char*	name;	/* config var name */
	ib_cfg_type_t	type;	/* config var type */
	ib_cfg_flag_t	flag;	/* config var flag */
	ib_uint64_t	min_val;/* minimum allowed value for numeric types,
				ignored for other types */
	ib_uint64_t	max_val;/* maximum allowed value for numeric types,
				ignored for other types */
	ib_err_t	(*validate)(const struct ib_cfg_var*, const void*); /*
				function used to validate a new variable's
				value when setting it */
	ib_err_t	(*set)(struct ib_cfg_var*, const void*); /* function
				used to set the variable's value */
	ib_err_t	(*get)(const struct ib_cfg_var*, void*); /* function
				used to get the variable's value */
	void*		tank;	/* opaque storage that may be used by the
				set() and get() functions */
} ib_cfg_var_t;

/***********************************************************************
Assign src to dst according to type. */
static
ib_err_t
ib_cfg_assign(
/*==========*/
				/* out: DB_SUCCESS if assigned (type is known) */
	ib_cfg_type_t	type,	/* in: type of src and dst */
	void*		dst,	/* out: destination */
	const void*	src,	/* in: source */
	ib_bool_t*	dst_allocd)/* out: IB_TRUE if dst has been
				allocated with ut_malloc(), used to determine
				whether it should be freed next time it is
				assigned */
{
	*dst_allocd = IB_FALSE;

	switch (type) {
	case IB_CFG_IBOOL: {

		*(ib_bool_t*) dst = *(const ib_bool_t*) src;
		return(DB_SUCCESS);
	}

	case IB_CFG_ULINT: {

		*(ulint*) dst = *(const ulint*) src;
		return(DB_SUCCESS);
	}

	case IB_CFG_ULONG: {

		*(ulong*) dst = *(const ulong*) src;
		return(DB_SUCCESS);
	}

	case IB_CFG_TEXT: {
		const char*	str;
		ulint		len;

		str = *(const char**) src;

		if (str == NULL) {
			*(char**) dst = NULL;
		} else {
			len = ut_strlen(str) + 1;

			/* Since we are using ut_malloc(), it's guaranteed
			to be freed during shutdown. */
			*(char**) dst = ut_malloc(len);
			*dst_allocd = IB_TRUE;
			ut_strcpy(*(char**) dst, str);
		}

		return(DB_SUCCESS);
	}

	case IB_CFG_CB: {

		*(ib_cb_t*) dst = *(ib_cb_t*) src;
		return(DB_SUCCESS);
	}
	/* do not add default: in order to produce a compilation
	warning if new type is added which is not handled here */
	}

	/* NOT REACHED */
	return(DB_ERROR);
}

/***********************************************************************
A generic function used for ib_cfg_var_t::validate() to check a numeric
type for min/max allowed value overflow. */
static
ib_err_t
ib_cfg_var_validate_numeric(
/*========================*/
					/* out: DB_SUCCESS if value is in
					range */
	const struct ib_cfg_var* cfg_var,/* in/out: configuration variable to
					check */
	const void*		value)	/* in: value to check */
{
	switch (cfg_var->type) {

	case IB_CFG_ULINT: {
		ulint	v;

		v = *(ulint*) value;

		if ((ulint) cfg_var->min_val <= v
		    && v <= (ulint) cfg_var->max_val) {

			return(DB_SUCCESS);
		} else {

			return(DB_INVALID_INPUT);
		}
	}

	case IB_CFG_ULONG: {
		ulong	v;

		v = *(ulong*) value;

		if ((ulong) cfg_var->min_val <= v
		    && v <= (ulong) cfg_var->max_val) {

			return(DB_SUCCESS);
		} else {

			return(DB_INVALID_INPUT);
		}
	}

	default:
		ut_error;
	}

	/* NOT REACHED */
	return(DB_ERROR);
}

/***********************************************************************
A generic function used for ib_cfg_var_t::set() that stores the value
of the configuration parameter in the location pointed by
ib_cfg_var_t::tank. */
static
ib_err_t
ib_cfg_var_set_generic(
/*===================*/
					/* out: DB_SUCCESS if set
					successfully */
	struct ib_cfg_var*	cfg_var,/* in/out: configuration variable to
					manipulate */
	const void*		value)	/* in: value to set */
{
	ib_err_t	ret;
	void*		old_tank;
	ib_bool_t	tank_is_allocd;

	if (cfg_var->validate != NULL) {
		if (!cfg_var->validate(cfg_var, value)) {
			return(DB_INVALID_INPUT);
		}
	}

	old_tank = *(void**) cfg_var->tank;

	ret = ib_cfg_assign(cfg_var->type, cfg_var->tank, value,
			    &tank_is_allocd);

	if (ret == DB_SUCCESS) {
		if (cfg_var->flag & IB_CFG_FLAG_TANK_IS_ALLOCD) {
			/* free the memory chunk allocated by previous
			assignments */
			ut_free(old_tank);
		}

		if (tank_is_allocd) {
			/* add to the flags */
			cfg_var->flag |= IB_CFG_FLAG_TANK_IS_ALLOCD;
		} else {
			/* remove from the flags */
			cfg_var->flag &= ~IB_CFG_FLAG_TANK_IS_ALLOCD;
		}
	}

	return(ret);
}

/***********************************************************************
A generic function used for ib_cfg_var_t::get() that retrieves the value
of the configuration parameter from the location pointed by
ib_cfg_var_t::tank. */
static
ib_err_t
ib_cfg_var_get_generic(
/*===================*/
						/* out: DB_SUCCESS if
						retrieved successfully */
	const struct ib_cfg_var*	cfg_var,/* in: configuration
						variable whose value to
						retrieve */
	void*				value)	/* out: place to store
						the retrieved value */
{
	ib_bool_t	unused;

	return(ib_cfg_assign(cfg_var->type, value, cfg_var->tank, &unused));
}

/***********************************************************************
Set the value of the config variable "adaptive_hash_index". */
static
ib_err_t
ib_cfg_var_set_adaptive_hash_index(
/*===============================*/
					/* out: DB_SUCCESS if set
					successfully */
	struct ib_cfg_var*	cfg_var,/* in/out: configuration variable to
					manipulate, must be
					"adaptive_hash_index" */
	const void*		value)	/* in: value to set, must point to
					ib_bool_t variable */
{
	ut_a(strcasecmp(cfg_var->name, "adaptive_hash_index") == 0);
	ut_a(cfg_var->type == IB_CFG_IBOOL);

	btr_search_enabled = !(*(const ib_bool_t*) value);

	return(DB_SUCCESS);
}

/***********************************************************************
Retrieve the value of the config variable "adaptive_hash_index". */
static
ib_err_t
ib_cfg_var_get_adaptive_hash_index(
/*===============================*/
						/* out: DB_SUCCESS if
						retrieved successfully */
	const struct ib_cfg_var*	cfg_var,/* in: configuration
						variable whose value to
						retrieve, must be
						"adaptive_hash_index" */
	void*				value)	/* out: place to store
						the retrieved value, must
						point to ib_bool_t variable */
{
	ut_a(strcasecmp(cfg_var->name, "adaptive_hash_index") == 0);
	ut_a(cfg_var->type == IB_CFG_IBOOL);

	*(ib_bool_t*) value = !btr_search_enabled;

	return(DB_SUCCESS);
}

/***********************************************************************
Set the value of the config variable "data_file_path". */
static
ib_err_t
ib_cfg_var_set_data_file_path(
/*==========================*/
					/* out: DB_SUCCESS if set
					successfully */
	struct ib_cfg_var*	cfg_var,/* in/out: configuration variable to
					manipulate, must be
					"data_file_path" */
	const void*		value)	/* in: value to set, must point to
					char* variable */
{
	const char*	value_str;

	ut_a(strcasecmp(cfg_var->name, "data_file_path") == 0);
	ut_a(cfg_var->type == IB_CFG_TEXT);

	value_str = *(char**) value;

	if (srv_parse_data_file_paths_and_sizes(value_str)) {
		return(DB_SUCCESS);
	} else {
		return(DB_INVALID_INPUT);
	}
}

/***********************************************************************
Retrieve the value of the config variable "data_file_path". */
static
ib_err_t
ib_cfg_var_get_data_file_path(
/*==========================*/
						/* out: DB_SUCCESS if
						retrieved successfully */
	const struct ib_cfg_var*	cfg_var,/* in: configuration
						variable whose value to
						retrieve, must be
						"data_file_path" */
	void*				value)	/* out: place to store
						the retrieved value, must
						point to char* variable */
{
	ut_a(strcasecmp(cfg_var->name, "data_file_path") == 0);
	ut_a(cfg_var->type == IB_CFG_TEXT);

	*(char**) value = srv_data_file_paths_and_sizes;

	return(DB_SUCCESS);
}

/***********************************************************************
Set the value of the config variable "file_format". */
static
ib_err_t
ib_cfg_var_set_file_format(
/*=======================*/
					/* out: DB_SUCCESS if set
					successfully */
	struct ib_cfg_var*	cfg_var,/* in/out: configuration variable to
					manipulate, must be "file_format" */
	const void*		value)	/* in: value to set, must point to
					char* variable */
{
	ulint		format_id;

	ut_a(strcasecmp(cfg_var->name, "file_format") == 0);
	ut_a(cfg_var->type == IB_CFG_TEXT);

	format_id = trx_sys_file_format_name_to_id(*(char**) value);

	if (format_id > DICT_TF_FORMAT_MAX) {
		return(DB_INVALID_INPUT);
	}

	srv_file_format = format_id;

	return(DB_SUCCESS);
}

/***********************************************************************
Retrieve the value of the config variable "file_format". */
static
ib_err_t
ib_cfg_var_get_file_format(
/*=======================*/
						/* out: DB_SUCCESS if
						retrieved successfully */
	const struct ib_cfg_var*	cfg_var,/* in: configuration
						variable whose value to
						retrieve, must be
						"file_format" */
	void*				value)	/* out: place to store
						the retrieved value, must
						point to char* variable */
{
	ut_a(strcasecmp(cfg_var->name, "file_format") == 0);
	ut_a(cfg_var->type == IB_CFG_TEXT);

	*(const char**) value = trx_sys_file_format_id_to_name(
		srv_file_format);

	return(DB_SUCCESS);
}

/***********************************************************************
Set the value of the config variable "log_group_home_dir". */
static
ib_err_t
ib_cfg_var_set_log_group_home_dir(
/*==============================*/
					/* out: DB_SUCCESS if set
					successfully */
	struct ib_cfg_var*	cfg_var,/* in/out: configuration variable to
					manipulate, must be
					"log_group_home_dir" */
	const void*		value)	/* in: value to set, must point to
					char* variable */
{
	const char*	value_str;

	ut_a(strcasecmp(cfg_var->name, "log_group_home_dir") == 0);
	ut_a(cfg_var->type == IB_CFG_TEXT);

	ut_a(srv_log_group_home_dir == NULL);

	value_str = *(char**) value;

	if (srv_parse_log_group_home_dirs(value_str)) {
		return(DB_SUCCESS);
	} else {
		return(DB_INVALID_INPUT);
	}
}

/***********************************************************************
Retrieve the value of the config variable "log_group_home_dir". */
static
ib_err_t
ib_cfg_var_get_log_group_home_dir(
/*==============================*/
						/* out: DB_SUCCESS if
						retrieved successfully */
	const struct ib_cfg_var*	cfg_var,/* in: configuration
						variable whose value to
						retrieve, must be
						"log_group_home_dir" */
	void*				value)	/* out: place to store
						the retrieved value, must
						point to char* variable */
{
	ut_a(strcasecmp(cfg_var->name, "log_group_home_dir") == 0);
	ut_a(cfg_var->type == IB_CFG_TEXT);

	*(const char**) value = NULL;

	return(DB_SUCCESS);
}

/* There is no ib_cfg_var_set_version() */

/***********************************************************************
Retrieve the value of the config variable "version". */
static
ib_err_t
ib_cfg_var_get_version(
/*===================*/
						/* out: DB_SUCCESS if
						retrieved successfully */
	const struct ib_cfg_var*	cfg_var,/* in: configuration
						variable whose value to
						retrieve, must be
						"version" */
	void*				value)	/* out: place to store
						the retrieved value, must
						point to char* variable */
{
	ut_a(strcasecmp(cfg_var->name, "version") == 0);
	ut_a(cfg_var->type == IB_CFG_TEXT);

	*(const char**) value = INNODB_VERSION_STR;

	return(DB_SUCCESS);
}

static const ib_cfg_var_t cfg_vars_defaults[] = {
	{STRUCT_FLD(name,	"adaptive_hash_index"),
	 STRUCT_FLD(type,	IB_CFG_IBOOL),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_adaptive_hash_index),
	 STRUCT_FLD(get,	ib_cfg_var_get_adaptive_hash_index),
	 STRUCT_FLD(tank,	NULL)},

	{STRUCT_FLD(name,	"additional_mem_pool_size"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	512 * 1024),
	 STRUCT_FLD(max_val,	IB_UINT64_T_MAX),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_mem_pool_size)},

	{STRUCT_FLD(name,	"autoextend_increment"),
	 STRUCT_FLD(type,	IB_CFG_ULONG),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	1),
	 STRUCT_FLD(max_val,	1000),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_auto_extend_increment)},

	{STRUCT_FLD(name,	"buffer_pool_size"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	5 * 1024 * 1024),
	 STRUCT_FLD(max_val,	ULINT_MAX),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_buf_pool_size)},

	{STRUCT_FLD(name,	"checksums"),
	 STRUCT_FLD(type,	IB_CFG_IBOOL),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_use_checksums)},

	{STRUCT_FLD(name,	"concurrency_tickets"),
	 STRUCT_FLD(type,	IB_CFG_ULONG),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	1),
	 STRUCT_FLD(max_val,	IB_UINT64_T_MAX),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_n_free_tickets_to_enter)},

	{STRUCT_FLD(name,	"data_file_path"),
	 STRUCT_FLD(type,	IB_CFG_TEXT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_data_file_path),
	 STRUCT_FLD(get,	ib_cfg_var_get_data_file_path),
	 STRUCT_FLD(tank,	NULL)},

	{STRUCT_FLD(name,	"data_home_dir"),
	 STRUCT_FLD(type,	IB_CFG_TEXT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_data_home)},

	{STRUCT_FLD(name,	"doublewrite"),
	 STRUCT_FLD(type,	IB_CFG_IBOOL),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_use_doublewrite_buf)},

	{STRUCT_FLD(name,	"fast_shutdown"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	2),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_fast_shutdown)},

	{STRUCT_FLD(name,	"file_format"),
	 STRUCT_FLD(type,	IB_CFG_TEXT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL /* validation is done inside
				     ib_cfg_var_set_file_format */),
	 STRUCT_FLD(set,	ib_cfg_var_set_file_format),
	 STRUCT_FLD(get,	ib_cfg_var_get_file_format),
	 STRUCT_FLD(tank,	NULL)},

	{STRUCT_FLD(name,	"file_io_threads"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	4),
	 STRUCT_FLD(max_val,	64),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_n_file_io_threads)},

	{STRUCT_FLD(name,	"file_per_table"),
	 STRUCT_FLD(type,	IB_CFG_IBOOL),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_file_per_table)},

	{STRUCT_FLD(name,	"flush_log_at_trx_commit"),
	 STRUCT_FLD(type,	IB_CFG_ULONG),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	2),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_flush_log_at_trx_commit)},

	{STRUCT_FLD(name,	"flush_method"),
	 STRUCT_FLD(type,	IB_CFG_TEXT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_file_flush_method_str)},

	{STRUCT_FLD(name,	"force_recovery"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	6),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_force_recovery)},

	{STRUCT_FLD(name,	"lock_wait_timeout"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	1),
	 STRUCT_FLD(max_val,	1024 * 1024 * 1024),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&ses_lock_wait_timeout)},

	{STRUCT_FLD(name,	"log_buffer_size"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	256 * 1024),
	 STRUCT_FLD(max_val,	IB_UINT64_T_MAX),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_log_buffer_size)},

	{STRUCT_FLD(name,	"log_file_size"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	1024 * 1024),
	 STRUCT_FLD(max_val,	ULINT_MAX),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_log_file_size)},

	{STRUCT_FLD(name,	"log_files_in_group"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	2),
	 STRUCT_FLD(max_val,	100),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_n_log_files)},

	{STRUCT_FLD(name,	"log_group_home_dir"),
	 STRUCT_FLD(type,	IB_CFG_TEXT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_log_group_home_dir),
	 STRUCT_FLD(get,	ib_cfg_var_get_log_group_home_dir),
	 STRUCT_FLD(tank,	NULL)},

	{STRUCT_FLD(name,	"max_dirty_pages_pct"),
	 STRUCT_FLD(type,	IB_CFG_ULONG),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	100),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_max_buf_pool_modified_pct)},

	{STRUCT_FLD(name,	"max_purge_lag"),
	 STRUCT_FLD(type,	IB_CFG_ULONG),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	IB_UINT64_T_MAX),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_max_purge_lag)},

	{STRUCT_FLD(name,	"mirrored_log_groups"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	1),
	 STRUCT_FLD(max_val,	10),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_n_log_groups)},

	{STRUCT_FLD(name,	"open_files"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY_AFTER_STARTUP),
	 STRUCT_FLD(min_val,	10),
	 STRUCT_FLD(max_val,	IB_UINT64_T_MAX),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_max_n_open_files)},

	/* New, not present in InnoDB/MySQL */
	{STRUCT_FLD(name,	"pre_rollback_hook"),
	 STRUCT_FLD(type,	IB_CFG_CB),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&recv_pre_rollback_hook)},

	/* New, not present in InnoDB/MySQL */
	{STRUCT_FLD(name,	"print_verbose_log"),
	 STRUCT_FLD(type,	IB_CFG_IBOOL),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_print_verbose_log)},

	/* New, not present in InnoDB/MySQL */
	{STRUCT_FLD(name,	"rollback_on_timeout"),
	 STRUCT_FLD(type,	IB_CFG_IBOOL),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&ses_rollback_on_timeout)},

	{STRUCT_FLD(name,	"stats_sample_pages"),
	 STRUCT_FLD(type,	IB_CFG_ULINT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	1),
	 STRUCT_FLD(max_val,	ULINT_MAX),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_stats_sample_pages)},

	{STRUCT_FLD(name,	"status_file"),
	 STRUCT_FLD(type,	IB_CFG_IBOOL),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_innodb_status)},

	{STRUCT_FLD(name,	"sync_spin_loops"),
	 STRUCT_FLD(type,	IB_CFG_ULONG),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	IB_UINT64_T_MAX),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_n_spin_wait_rounds)},

	{STRUCT_FLD(name,	"thread_concurrency"),
	 STRUCT_FLD(type,	IB_CFG_ULONG),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	1000),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_thread_concurrency)},

	{STRUCT_FLD(name,	"thread_sleep_delay"),
	 STRUCT_FLD(type,	IB_CFG_ULONG),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_NONE),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	IB_UINT64_T_MAX),
	 STRUCT_FLD(validate,	ib_cfg_var_validate_numeric),
	 STRUCT_FLD(set,	ib_cfg_var_set_generic),
	 STRUCT_FLD(get,	ib_cfg_var_get_generic),
	 STRUCT_FLD(tank,	&srv_thread_sleep_delay)},

	{STRUCT_FLD(name,	"version"),
	 STRUCT_FLD(type,	IB_CFG_TEXT),
	 STRUCT_FLD(flag,	IB_CFG_FLAG_READONLY),
	 STRUCT_FLD(min_val,	0),
	 STRUCT_FLD(max_val,	0),
	 STRUCT_FLD(validate,	NULL),
	 STRUCT_FLD(set,	NULL /* The ::set() function should never
				     be called because this variable is
				     flagged as IB_CFG_FLAG_READONLY */),
	 STRUCT_FLD(get,	ib_cfg_var_get_version),
	 STRUCT_FLD(tank,	NULL)},
};

static ib_cfg_var_t cfg_vars[UT_ARR_SIZE(cfg_vars_defaults)];

/*************************************************************************
Lookup a variable name. */
static
ib_cfg_var_t*
ib_cfg_lookup_var(
/*==============*/
					/* out: config variable instance if
					found else NULL */
	const char*	var)		/* in: variable name */
{
	ulint		i;

	for (i = 0; i < UT_ARR_SIZE(cfg_vars); ++i) {
		ib_cfg_var_t*	cfg_var;

		cfg_var = &cfg_vars[i];

		if (strcasecmp(var, cfg_var->name) == 0) {
			return(cfg_var);
		}
	}

	return(NULL);
}

/*************************************************************************
Get the type of a configuration variable. Returns DB_SUCCESS if the
variable with name "name" was found and "type" was set. */
UNIV_INTERN
ib_err_t
ib_cfg_var_get_type(
/*================*/
					/* out: DB_SUCCESS if successful */
	const char*	name,		/* in: variable name */
	ib_cfg_type_t*	type)		/* out: variable type */
{
	ib_cfg_var_t*	cfg_var;

	cfg_var = ib_cfg_lookup_var(name);

	if (cfg_var != NULL) {
		*type = cfg_var->type;
		return(DB_SUCCESS);
	}

	return(DB_NOT_FOUND);
}

/*************************************************************************
Set a configuration variable. "ap" must contain one argument whose type
depends on the type of the variable with the given "name". Returns
DB_SUCCESS if the variable with name "name" was found and if its value
was set. */
UNIV_INTERN
ib_err_t
ib_cfg_set_ap(
/*==========*/
					/* out: DB_SUCCESS if set */
	const char*	name,		/* in: variable name */
	va_list		ap)		/* in: variable value */
{
	ib_cfg_var_t*	cfg_var;

	cfg_var = ib_cfg_lookup_var(name);

	if (cfg_var != NULL) {

		/* check whether setting the variable is appropriate,
		according to its flag */
		if (cfg_var->flag & IB_CFG_FLAG_READONLY) {
			return(DB_READONLY);
		}

		if (cfg_var->flag & IB_CFG_FLAG_READONLY_AFTER_STARTUP
		    && srv_was_started) {
			return(DB_READONLY);
		}

		/* get the parameter according to its type and call ::set() */
		switch (cfg_var->type) {
		case IB_CFG_IBOOL: {
			ib_bool_t	value;

			value = va_arg(ap, ib_bool_t);

			return(cfg_var->set(cfg_var, &value));
		}

		case IB_CFG_ULINT: {
			ulint	value;

			value = va_arg(ap, ulint);

			return(cfg_var->set(cfg_var, &value));
		}

		case IB_CFG_ULONG: {
			ulong	value;

			value = va_arg(ap, ulong);

			return(cfg_var->set(cfg_var, &value));
		}

		case IB_CFG_TEXT: {
			const char*	value;

			value = va_arg(ap, const char*);

			return(cfg_var->set(cfg_var, &value));
		}

		case IB_CFG_CB: {
			ib_cb_t	value;

			value = va_arg(ap, ib_cb_t);

			return(cfg_var->set(cfg_var, &value));
		}
		/* do not add default: in order to produce a compilation
		warning if new type is added which is not handled here */
		}
	}

	return(DB_NOT_FOUND);
}

/*************************************************************************
Set a configuration variable. The second argument's type depends on the
type of the variable with the given "name". Returns DB_SUCCESS if the
variable with name "name" was found and if its value was set. */
UNIV_INTERN
ib_err_t
ib_cfg_set(
/*=======*/
					/* out: DB_SUCCESS if set */
	const char*	name,		/* in: variable name */
	...)				/* in: variable value */
{
	va_list		ap;
	ib_bool_t	ret;

	va_start(ap, name);

	ret = ib_cfg_set_ap(name, ap);

	va_end(ap);

	return(ret);
}

/*************************************************************************
Get the value of a configuration variable. The type of the returned value
depends on the type of the configuration variable. DB_SUCCESS is returned
if the variable with name "name" was found and "value" was set. */
UNIV_INTERN
ib_err_t
ib_cfg_get(
/*=======*/
					/* out: DB_SUCCESS if retrieved
					successfully */
	const char*	name,		/* in: variable name */
	void*		value)		/* out: place to store the retrieved
					value */
{
	ib_cfg_var_t*	cfg_var;

	cfg_var = ib_cfg_lookup_var(name);

	if (cfg_var != NULL) {
		return(cfg_var->get(cfg_var, value));
	}

	return(DB_NOT_FOUND);
}

/*************************************************************************
Initialize the config system. */
UNIV_INTERN
ib_err_t
ib_cfg_init(void)
/*=============*/
	/* out: DB_SUCCESS or error code */
{
	ut_memcpy(cfg_vars, cfg_vars_defaults, sizeof(cfg_vars));

#define IB_CFG_SET(name, var)	\
	if (ib_cfg_set(name, var) != DB_SUCCESS) ut_error

	IB_CFG_SET("additional_mem_pool_size", 4 * 1024 * 1024);
	IB_CFG_SET("buffer_pool_size", 8 * 1024 * 1024);
	IB_CFG_SET("data_file_path", "ibdata1:32M:autoextend");
	IB_CFG_SET("data_home_dir", ".");
	IB_CFG_SET("file_io_threads", 4);
	IB_CFG_SET("file_per_table", IB_TRUE);
	IB_CFG_SET("flush_method", "fsync");
	IB_CFG_SET("lock_wait_timeout", 60);
	IB_CFG_SET("log_buffer_size", 384 * 1024);
	IB_CFG_SET("log_file_size", 16 * 1024 * 1024);
	IB_CFG_SET("log_files_in_group", 2);
	IB_CFG_SET("log_group_home_dir", ".");
	/* XXX ha_innodb.cc says mirrored_log_groups should be set to 1,
	why is it set to 2? */
	IB_CFG_SET("mirrored_log_groups", 2);
	IB_CFG_SET("rollback_on_timeout", IB_TRUE);
#undef IB_CFG_SET

	return(DB_SUCCESS);
}

/*************************************************************************
Shutdown the config system. */
UNIV_INTERN
ib_err_t
ib_cfg_shutdown(void)
/*=================*/
{
	memset(cfg_vars, 0x0, sizeof(cfg_vars));

	return(DB_SUCCESS);
}
