/***********************************************************************
Copyright (c) 2008, 2009 Innobase Oy. All rights reserved.
Copyright (c) 2008, 2009 Oracle. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

************************************************************************/
#ifndef INNOBASE_API_H
#define INNOBASE_API_H

#include "db0err.h"

/* API_BEGIN_INCLUDE */
#include <stdio.h>

#ifdef _MSC_VER
#define strncasecmp _strnicmp
#define strcasecmp _stricmp
#endif

/* See comment about ib_bool_t as to why the two macros are unsigned long. */
#define IB_TRUE		0x1UL
#define IB_FALSE	0x0UL

/* Basic types used by the InnoDB API. */
typedef enum db_err             ib_err_t;
typedef unsigned char           ib_byte_t;
typedef unsigned long int       ib_ulint_t;
typedef void*                   ib_opaque_t;
/* Ideally we would like to have this as ib_byte_t, but we need to make it
the same as the InnoDB internal ibool. */
typedef ib_ulint_t              ib_bool_t;
typedef ib_opaque_t             ib_charset_t;

/* We assume C99 support except when using VisualStudio. */
#if !defined(_MSC_VER)
#include <stdint.h>
#endif /* _MSC_VER */

/* Integer types used by the API. Microsft VS defines its own types
and we use the Microsoft types when building with Visual Studio. */
#if defined(_MSC_VER)
typedef __int8			ib_i8_t;
#else
typedef int8_t                  ib_i8_t;
#endif

#if defined(_MSC_VER)
typedef unsigned __int8		ib_u8_t;
#else
typedef uint8_t                 ib_u8_t;
#endif

#if defined(_MSC_VER)
typedef __int16			ib_i16_t;
#else
typedef int16_t                 ib_i16_t;
#endif

#if defined(_MSC_VER)
typedef unsigned __int16	ib_u16_t;
#else
typedef uint16_t                ib_u16_t;
#endif

#if defined(_MSC_VER)
typedef __int32			ib_i32_t;
#else
typedef int32_t                 ib_i32_t;
#endif

#if defined(_MSC_VER)
typedef unsigned __int32	ib_u32_t;
#else
typedef uint32_t                ib_u32_t;
#endif

#if defined(_MSC_VER)
typedef __int64			ib_i64_t;
#else
typedef int64_t                 ib_i64_t;
#endif

#if defined(_MSC_VER)
typedef unsigned __int64	ib_u64_t;
#else
typedef uint64_t                ib_u64_t;
#endif

typedef ib_u64_t                ib_id_t;

/* Possible types for a configuration variable. */
typedef enum ib_cfg_type {
	IB_CFG_IBOOL,	/* ibool type */
	/* XXX Can we avoid having different types for ulint and ulong?
	- On Win64 "unsigned long" is 32 bits
	- ulong is always defined as "unsigned long"
	- On Win64 ulint is defined as 64 bit integer
	=> On Win64 ulint != ulong.
	If we typecast all ulong and ulint variables to the smaller type
	ulong, then we will cut the range of the ulint variables.
	This is not a problem for most ulint variables because their max
	allowed values do not exceed 2^32-1 (e.g. log_groups is ulint
	but its max allowed value is 10). BUT buffer_pool_size and
	log_file_size allow up to 2^64-1. */
	IB_CFG_ULINT,	/* ulint type */
	IB_CFG_ULONG,	/* ulong type */
	IB_CFG_TEXT,	/* char* type */
	IB_CFG_CB,	/* ib_cb_t type */
} ib_cfg_type_t;

/* InnoDB column types that are supported. */
typedef enum ib_col_type_enum {
	IB_VARCHAR =	1,		/* Character varying length */
	IB_CHAR =	2,		/* Fixed length character string */
	IB_NOT_USED1 =	3,		/* Future use, reserved */
	IB_NOT_USED2 =	4,		/* Future use, reserved */
	IB_BLOB	=	5,		/* Binary large object, or
					a TEXT type */
	IB_INT =	6,		/* Integer: can be any size
					1 - 8 bytes */

	IB_SYS =	8,		/* System column */

	IB_FLOAT =	9,
	IB_DOUBLE =	10,
	IB_VARCHAR_ANYCHARSET =	11,	/* Any charset, varying length */
	IB_CHAR_ANYCHARSET =	12,	/* Any charset, fixed length */
	IB_NOT_USED5 =	13		/* Future use, reserved */
} ib_col_type_t;

/* InnoDB table format types */
typedef enum ib_tbl_fmt_enum {
	IB_TBL_REDUNDANT,		/* Redundant row format */
	IB_TBL_COMPACT,			/* Compact row format */
	IB_TBL_DYNAMIC,			/* Compact row format. BLOB prefixes
					are not stored in the clustered index */
	IB_TBL_COMPRESSED,		/* Similar to dynamic format but
					with pages compressed */
} ib_tbl_fmt_t;

/* InnoDB column attributes */
typedef enum ib_col_attr_enum {
	IB_COL_NONE = 0,		/* No special attributes. */
	IB_COL_NOT_NULL = 1,		/* Column can't be NULL. */
	IB_COL_UNSIGNED = 2,		/* Column is IB_INT and unsigned. */
	IB_COL_NOT_USED = 4,		/* Future use, reserved. */
	IB_COL_CUSTOM1 = 8,		/* Custom precision type */
	IB_COL_CUSTOM2 = 16,		/* Custom precision type */
	IB_COL_CUSTOM3 = 32		/* Custom precision type */
} ib_col_attr_t;

/* InnoDB lock modes (must match lock0types.h) */
typedef enum ib_lck_mode_enum {
	IB_LOCK_IS = 0,			/* intention shared */
	IB_LOCK_IX,			/* intention exclusive */
	IB_LOCK_S,			/* shared */
	IB_LOCK_X,			/* exclusive */
	IB_LOCK_NOT_USED,		/* Future use, reserved */
	IB_LOCK_NONE,			/* this is used elsewhere to note
					consistent read */
	IB_LOCK_NUM = IB_LOCK_NONE	/* number of lock modes */
} ib_lck_mode_t;

/* InnoDB cursor search modes for ib_cursor_moveto().
Note: Valies must match those found in page0cur.h */
typedef enum ib_srch_mode_enum {
	IB_CUR_G = 1,			/* If search key is not found then
					position the cursor on the row that
					is greater than the search key */
	IB_CUR_GE = 2,			/* If the search key not found then
					position the cursor on the row that
					is greater than or equal to the search
					key */
	IB_CUR_L = 3,			/* If search key is not found then
					position the cursor on the row that
					is less than the search key */
	IB_CUR_LE = 4			/* If search key is not found then
					position the cursor on the row that
					is less than or equal to the search
					key */
} ib_srch_mode_t;

/* Various match modes used by ib_cursor_moveto() */
typedef enum ib_match_mode_enum {
	IB_CLOSEST_MATCH,		/* Closest match possible */
	IB_EXACT_MATCH,			/* Search using a complete key value */
	IB_EXACT_PREFIX			/* Search using a key prefix which
					must match to rows: the prefix may
					contain an incomplete field (the
					last field in prefix may be just
					a prefix of a fixed length column) */
} ib_match_mode_t;

/* InnoDB column meta data. */
typedef struct ib_col_meta_t {
	ib_col_type_t	type;		/* Type of the column */
	ib_col_attr_t	attr;		/* Column attributes */
	ib_u32_t	type_len;	/* Length of type */
	ib_u16_t	client_type;	/* 16 bits of data relevant only to
					the client. InnoDB doesn't care */
	ib_charset_t*	charset;	/* Column charset */
} ib_col_meta_t;

/* Transaction (must be in sync with trx0trx.h) */
typedef enum ib_trx_state_t {
	IB_TRX_NOT_STARTED,		/* Has not started yet */
	IB_TRX_ACTIVE,			/* Is currently active */
	IB_TRX_COMMITTED_IN_MEMORY,	/* Not committed to disk yet */
	IB_TRX_PREPARED			/* Support for 2PC/XA */
} ib_trx_state_t;

/* Transaction isolation levels (must match trx0trx.h) */
typedef enum ib_trx_level_enum {
	IB_TRX_READ_UNCOMMITTED = 0,	/* Dirty read: non-locking SELECTs are
					performed so that we do not look at a
					possible earlier version of a record;
					thus they are not 'consistent' reads
					under this isolation level; otherwise
					like level 2 */

	IB_TRX_READ_COMMITTED = 1,	/* Somewhat Oracle-like isolation,
					except that in range UPDATE and DELETE
					we must block phantom rows with
					next-key locks; SELECT ... FOR UPDATE
					and ...  LOCK IN SHARE MODE only lock
					the index records, NOT the gaps before
					them, and thus allow free inserting;
					each consistent read reads its own
					snapshot */

	IB_TRX_REPEATABLE_READ = 2,	/* All consistent reads in the same
					trx read the same snapshot; full
					next-key locking used in locking reads
					to block insertions into gaps */

	IB_TRX_SERIALIZABLE = 3		/* All plain SELECTs are converted to
					LOCK IN SHARE MODE reads */
} ib_trx_level_t;

/* Generical InnoDB callback prototype. */
typedef void (*ib_cb_t)(void);

/* The first argument to the InnoDB message logging function. By default
it's set to stderr. */
typedef FILE* ib_msg_stream_t;

/* All log messages are written to this function. It should have
 the same behavior as fprintf(3). */
typedef int (*ib_msg_log_t)(ib_msg_stream_t, const char*, ...);

/* Note: This is to make it easy for API users to have type
checking for arguments to our functions. Making it ib_opaque_t
by itself will result in pointer decay resulting in subverting
of the compiler's type checking. */
typedef struct ib_tpl_struct ib_tpl_struct;
typedef struct ib_trx_struct ib_trx_struct;
typedef struct ib_crsr_struct ib_crsr_struct;
typedef struct ib_tbl_sch_struct ib_tbl_sch_struct;
typedef struct ib_idx_sch_struct ib_idx_sch_struct;

typedef ib_tpl_struct* ib_tpl_t;
typedef ib_trx_struct* ib_trx_t;
typedef ib_crsr_struct* ib_crsr_t;
typedef ib_tbl_sch_struct* ib_tbl_sch_t;
typedef ib_idx_sch_struct* ib_idx_sch_t;

/* ib_schema_visitor_t version.  Currently, this is also the number of
callback functions in the struct. */
enum ib_schema_visitor_version {
	IB_SCHEMA_VISITOR_TABLE = 1,
	IB_SCHEMA_VISITOR_TABLE_COL = 2,
	IB_SCHEMA_VISITOR_TABLE_AND_INDEX = 3,
	IB_SCHEMA_VISITOR_TABLE_AND_INDEX_COL = 4
};

typedef int (*ib_schema_visitor_table_all_t) (
					/* return 0 on success, nonzero
					on failure (abort traversal) */
	void*		arg,		/* User callback arg */
	const char*	name,		/* Table name */
	int		name_len);	/* Length of name in bytes */

/* Table visitor */
typedef int (*ib_schema_visitor_table_t) (
					/* return 0 on success, nonzero
					on failure (abort traversal) */
	void*		arg,		/* User callback arg */
	const char*	name,		/* Table name */
	ib_tbl_fmt_t	tbl_fmt,	/* Table type */
	ib_ulint_t	page_size,	/* Table page size */
	int		n_cols,		/* No. of cols defined */
	int		n_indexes);	/* No. of indexes defined */

/* Table column visitor */
typedef int (*ib_schema_visitor_table_col_t) (
					/* return 0 on success, nonzero
					on failure (abort traversal) */
	void*		arg,		/* User callback arg */
	const char*	name,		/* Column name */
	ib_col_type_t	col_type,	/* Column type */
	ib_ulint_t	len,		/* Column len */
	ib_col_attr_t	attr);		/* Column attributes */

/* Index visitor */
typedef int (*ib_schema_visitor_index_t) (
					/* return 0 on success, nonzero
					on failure (abort traversal) */
	void*		arg,		/* User callback arg */
	const char*	name,		/* Index name */
	ib_bool_t	clustered,	/* True if clustered */
	ib_bool_t	unique,		/* True if unique */
	int		n_cols);	/* No. of cols defined */

/* Index column visitor */
typedef int (*ib_schema_visitor_index_col_t) (
					/* return 0 on success, nonzero
					on failure (abort traversal) */
	void*		arg,		/* User callback arg */
	const char*	name,		/* Column name */
	ib_ulint_t	prefix_len);	/* Prefix length */

/* Callback functions to traverse the schema of a table. */
typedef struct ib_schema_visitor_t {
	enum	ib_schema_visitor_version	version;
					/* Visitor version */
	ib_schema_visitor_table_t		table;
	ib_schema_visitor_table_col_t		table_col;
	ib_schema_visitor_index_t		index;
	ib_schema_visitor_index_col_t		index_col;
} ib_schema_visitor_t;

/*****************************************************************
This function is used to compare two data fields for which the data type
is such that we must use the client code to compare them. */
typedef int (*ib_client_cmp_t)(
					/* out: 1, 0, -1, if a is greater,
					equal, less than b, respectively */
	const ib_col_meta_t*
			col_meta,	/* in: column meta data */
	const ib_byte_t*p1,		/* in: key */
	ib_ulint_t	p1_len,		/* in: key length */
	const ib_byte_t*p2,		/* in: key */
	ib_ulint_t	p2_len);	/* in: key length */

/* This should be the same as univ.i */
#define	IB_SQL_NULL		0xFFFFFFFF
#define IB_N_SYS_COLS		3

#define MAX_TEXT_LEN		4096
#define IB_MAX_COL_NAME_LEN	64	// FIXME: What's the correct value ?
#define IB_MAX_TABLE_NAME_LEN	1024	// FIXME: What's the correct value ?

#define ib_tbl_sch_add_blob_col(s, n) \
	ib_table_schema_add_col(s, n, IB_BLOB, IB_COL_NONE, 0, 0)

#define ib_tbl_sch_add_text_col(s, n) \
	ib_table_schema_add_col(s, n, IB_VARCHAR, IB_COL_NONE, 0, MAX_TEXT_LEN)

#define ib_tbl_sch_add_varchar_col(s, n, l) \
	ib_table_schema_add_col(s, n, IB_VARCHAR, IB_COL_NONE, 0, l)

#define ib_tbl_sch_add_u32_col(s, n) \
	ib_table_schema_add_col(s, n, IB_INT, IB_COL_UNSIGNED, 0, 4)

#define ib_tbl_sch_add_u64_col(s, n) \
	ib_table_schema_add_col(s, n, IB_INT, IB_COL_UNSIGNED, 0, 8)

#define ib_tbl_sch_add_u64_notnull_col(s, n) \
	ib_table_schema_add_col(s, n, IB_INT, \
			        IB_COL_NOT_NULL | IB_COL_UNSIGNED,0,\
				8)
/*************************************************************************
Set an int configuration variable. */
#define ib_cfg_set_int(name, value)	ib_cfg_set(name, value)

/*************************************************************************
Set a text configuration variable. */
#define ib_cfg_set_text(name, value)	ib_cfg_set(name, value)

/*************************************************************************
Set a boolean configuration variable to IB_TRUE. */
#define ib_cfg_set_bool_on(name)	ib_cfg_set(name, IB_TRUE)

/*************************************************************************
Set a boolean configuration variable to IB_FALSE. */
#define ib_cfg_set_bool_off(name)	ib_cfg_set(name, IB_FALSE)

/*************************************************************************
Set a generic ib_cb_t callback function. */
#define ib_cfg_set_callback(name, value) ib_cfg_set(name, value)

extern ib_client_cmp_t	ib_client_compare;

/*********************************************************************
Return the API version number, the version number format is:
| 16 bits future use | 16 bits current | 16 bits revision | 16 bits age |

- If the library source code has changed at all since the last release,
  then revision will be incremented (`c:r:a' becomes `c:r+1:a').
- If any interfaces have been added, removed, or changed since the last
  update, current will be incremented, and revision will be set to 0.
- If any interfaces have been added (but not changed or removed) since
  the last release, then age will be incremented.
- If any interfaces have been changed or removed since the last release,
  then age will be set to 0.
*/

ib_u64_t
ib_api_version(void);
/*=================*/
					/* out: API version number */

/*********************************************************************
Initialize the InnoDB engine. This must be called prior to calling
any other InnoDB API function. */

ib_err_t
ib_init(void);
/*=========*/
					/* out: DB_SUCCESS or error code */

/*********************************************************************
Startup the InnoDB engine. */

ib_err_t
ib_startup(
/*=======*/
					/* out: DB_SUCCESS or error code */
	const char* format);		/* in: file format name */

/*********************************************************************
Shutdown the InnoDB engine. */

ib_err_t
ib_shutdown(void);
/*=============*/
					/* out: DB_SUCCESS or error code */

/*********************************************************************
Start a transaction that's been rolled back. */

ib_err_t
ib_trx_start(
/*=========*/
					/* out: innobase txn handle */
	ib_trx_t	ib_trx,		/* in: transaction to restart */
	ib_trx_level_t	ib_trx_level);	/* in: trx isolation level */

/*********************************************************************
Begin a transaction. This will allocate a new transaction handle. */

ib_trx_t
ib_trx_begin(
/*=========*/
					/* out: innobase txn handle */
	ib_trx_level_t	ib_trx_level);	/* in: trx isolation level */

/*********************************************************************
Get the transaction's state. */

ib_trx_state_t
ib_trx_state(
/*=========*/
					/* out: transaction state */
	ib_trx_t	ib_trx);	/* in: trx handle */

/*********************************************************************
Release the resources of the transaction. */

ib_err_t
ib_trx_release(
/*===========*/
					/* out: DB_SUCCESS or err code */
	ib_trx_t	ib_trx);	/* in: trx handle */

/*********************************************************************
Commit a transaction. This function will also release the schema
latches too. */

ib_err_t
ib_trx_commit(
/*==========*/
					/* out: DB_SUCCESS or err code */
	ib_trx_t	ib_trx);	/* in: trx handle */

/*********************************************************************
Rollback a transaction. This function will also release the schema
latches too. */

ib_err_t
ib_trx_rollback(
/*============*/
					/* out: DB_SUCCESS or err code */
	ib_trx_t	ib_trx);	/* in: trx handle */

/*********************************************************************
Add columns to a table schema. */

ib_err_t
ib_table_schema_add_col(
/*====================*/
					/* out: DB_SUCCESS or err code */
	ib_tbl_sch_t	ib_tbl_sch,	/* in: schema instance */
	const char*	name,		/* in: name of column */
	ib_col_type_t	ib_col_type,	/* in: column main type */
	ib_col_attr_t	ib_col_attr,	/* in: column attributes */
	ib_u16_t	client_type,	/* in: any 16 bit number relevant
					only to the client */
	ib_ulint_t	len);		/* in: max length of column */

/*********************************************************************
Create and add an index key definition to a table schema. The index
schema is owned by the table schema instance and will be freed when
the table schema instance is freed. */

ib_err_t
ib_table_schema_add_index(
/*======================*/
					/* out: DB_SUCCESS or err code */
	ib_tbl_sch_t	ib_tbl_sch,	/* in/out: schema instance */
	const char*	name,		/* in: key defn. name to create */
	ib_idx_sch_t*	ib_idx_sch);	/* out: key definition instance */

/*********************************************************************
Destroy a schema. */

void
ib_table_schema_delete(
/*===================*/
	ib_tbl_sch_t	ib_tbl_sch);	/* in, own: table schema to delete */

/*********************************************************************
Set temporary directory for tablespace. */

ib_err_t
ib_table_schema_set_temp_dir(
/*=========================*/
					/* out: DB_SUCCESS or err code */
	ib_tbl_sch_t	ib_tbl_sch,	/* in/out: table schema instance */
	const char*	path);		/* in: path for temp table */

/*********************************************************************
Create a table schema. */

ib_err_t
ib_table_schema_create(
/*===================*/
					/* out: DB_SUCCESS or err code */
	const char*	name,		/* in: table name to create */
	ib_tbl_sch_t*	ib_tbl_sch,	/* out: schema instance */
	ib_tbl_fmt_t	ib_tbl_fmt,	/* in: Table format */
	ib_ulint_t	page_size);	/* in: Page size or 0 for default */

/*********************************************************************
Add columns to a schema definition. */

ib_err_t
ib_index_schema_add_col(
/*====================*/
					/* out: DB_SUCCESS or err code */
	ib_idx_sch_t	ib_idx_sch,	/* in/out: index schema instance */
	const char*	name,		/* in: name of column */
	ib_ulint_t	prefix_len);	/* in: length of prefix or 0 */

/*********************************************************************
Create an index schema instance. */

ib_err_t
ib_index_schema_create(
/*===================*/
					/* out: DB_SUCCESS or err code */
	ib_trx_t	ib_usr_trx,	/* in: current user transaction */
	const char*	name,		/* in: index name in schema */
	const char*	table_name,	/* in: table name */
	ib_idx_sch_t*	ib_idx_sch);	/* out: index schema instance */

/*********************************************************************
Set index as clustered index. Implies UNIQUE. */

ib_err_t
ib_index_schema_set_clustered(
/*==========================*/
					/* out: DB_SUCCESS or err code */
	ib_idx_sch_t	ib_idx_sch);	/* in/out: index definition */

/*********************************************************************
Set to true if it's a simple select. */

void
ib_cursor_set_simple_select(
/*========================*/
	ib_crsr_t	ib_crsr);	/* in/out: InnoDB cursor */

/*********************************************************************
Set index as a unique index. */

ib_err_t
ib_index_schema_set_unique(
/*=======================*/
					/* out: DB_SUCCESS or err code */
	ib_idx_sch_t	ib_idx_sch);	/* in/out: index definition */

/*********************************************************************
Destroy an index schema. */

void
ib_index_schema_delete(
/*===================*/
	ib_idx_sch_t	ib_idx_sch);	/* in, own: index schema to delete */

/*********************************************************************
Create a table. If the table exists in the database then this function
will return DB_TABLE_IS_BEING_USED and id will contain that tables id. */

ib_err_t
ib_table_create(
/*============*/
					/* out: DB_SUCCESS
					or err code */
	ib_trx_t	ib_trx,		/* in/out: transaction */
	const ib_tbl_sch_t		/* in: table schema */
			ib_tbl_sch,
	ib_id_t*	id);		/* out: table id */

/*********************************************************************
Rename a table. */

ib_err_t
ib_table_rename(
/*============*/
					/* out: DB_SUCCESS or err code */
	ib_trx_t	ib_trx,		/* in/out: transaction */
	const char*	old_name,	/* in: old name*/
	const char*	new_name);	/* in: old name*/

/*********************************************************************
Create a secondary index. The index id encodes the table id in the high
4 bytes and the index id in the lower 4 bytes. */

ib_err_t
ib_index_create(
/*============*/
					/* out: DB_SUCCESS or err code */
	ib_idx_sch_t	ib_idx_sch,	/* in/out: key definition for index */
	ib_id_t*	index_id);	/* out: index id */

/*********************************************************************
Drop a table. */

ib_err_t
ib_table_drop(
/*==========*/
					/* out: DB_SUCCESS or err code */
	const char*	name);		/* in: table name to drop*/

/*********************************************************************
Drop a secondary index. */

ib_err_t
ib_index_drop(
/*==========*/
					/* out: DB_SUCCESS or err code */
	ib_id_t		index_id);	/* in: index id to drop */

/*********************************************************************
Open an InnoDB table and return a cursor handle to it. */

ib_err_t
ib_cursor_open_table_using_id(
/*==========================*/
					/* out: DB_SUCCESS or err code */
	ib_id_t		table_id,	/* in: table id of table to open */
	ib_trx_t	ib_trx,		/* in: Current transaction handle
					can be NULL */
	ib_crsr_t*	ib_crsr);	/* out,own: InnoDB cursor */

/*********************************************************************
Open an InnoDB index and return a cursor handle to it. */

ib_err_t
ib_cursor_open_index_using_id(
/*==========================*/
					/* out: DB_SUCCESS or err code */
	ib_id_t		index_id,	/* in: index id of index to open */
	ib_trx_t	ib_trx,		/* in: Current transaction handle
					can be NULL */
	ib_crsr_t*	ib_crsr);	/* out: InnoDB cursor */

/*********************************************************************
Open an InnoDB secondary index cursor and return a cursor handle to it. */

ib_err_t
ib_cursor_open_index_using_name(
/*============================*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_open_crsr,	/* in: open/active cursor */
	const char*	index_name,	/* in: secondary index name */
	ib_crsr_t*	ib_crsr);	/* out,own: InnoDB index cursor */

/*********************************************************************
Open an InnoDB table by name and return a cursor handle to it. */

ib_err_t
ib_cursor_open_table(
/*=================*/
					/* out: DB_SUCCESS or err code */
	const char*	name,		/* in: table name */
	ib_trx_t	ib_trx,		/* in: Current transaction handle
					can be NULL */
	ib_crsr_t*	ib_crsr);	/* out,own: InnoDB cursor */

/*********************************************************************
Reset the cursor. */

ib_err_t
ib_cursor_reset(
/*============*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr);	/* in/out: InnoDB cursor */

/*********************************************************************
Close an InnoDB table and free the cursor. */

ib_err_t
ib_cursor_close(
/*============*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr);	/* in,own: InnoDB cursor */

/*********************************************************************
Insert a row to a table. */

ib_err_t
ib_cursor_insert_row(
/*=================*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr,	/* in/out: InnoDB cursor instance */
	const ib_tpl_t	ib_tpl);	/* in: tuple to insert */

/*********************************************************************
Update a row in a table. */

ib_err_t
ib_cursor_update_row(
/*=================*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr,	/* in: InnoDB cursor instance */
	const ib_tpl_t	ib_old_tpl,	/* in: Old tuple in table */
	const ib_tpl_t	ib_new_tpl);	/* in: New tuple to update */

/*********************************************************************
Delete a row in a table. */

ib_err_t
ib_cursor_delete_row(
/*=================*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr);	/* in: InnoDB cursor instance */

/*********************************************************************
Read current rowe. */

ib_err_t
ib_cursor_read_row(
/*===============*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr,	/* in: InnoDB cursor instance */
	ib_tpl_t	ib_tpl);	/* out: read cols into this tuple */

/*********************************************************************
Move cursor to the prev user record in the table. */

ib_err_t
ib_cursor_prev(
/*===========*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr);	/* in: InnoDB cursor instance */

/*********************************************************************
Move cursor to the next user record in the table. */

ib_err_t
ib_cursor_next(
/*===========*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr);	/* in: InnoDB cursor instance */

/*********************************************************************
Move cursor to the first record in the table. */

ib_err_t
ib_cursor_first(
/*============*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr);	/* in: InnoDB cursor instance */

/*********************************************************************
Move cursor to the last record in the table. */

ib_err_t
ib_cursor_last(
/*===========*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr);	/* in: InnoDB cursor instance */

/*********************************************************************
Search for key. */

ib_err_t
ib_cursor_moveto(
/*=============*/
					/* out: DB_SUCCESS or err code */
	ib_crsr_t	ib_crsr,	/* in: InnoDB cursor instance */
	ib_tpl_t	ib_tpl,		/* in: Key to search for */
	ib_srch_mode_t	ib_srch_mode,	/* in: search mode */
	int*		result);	/* out: -1, 0 or 1 depending on
					tuple eq or gt than current row */

/*********************************************************************
Attach the cursor to the transaction. */

void
ib_cursor_attach_trx(
/*=================*/
	ib_crsr_t	ib_crsr,	/* in: cursor instance */
	ib_trx_t	ib_trx);	/* in: transaction */

/*********************************************************************
Set the client comparison function for BLOBs and client types. */

void
ib_set_client_compare(
/*==================*/
	ib_client_cmp_t	client_cmp_func);/* in: client col. compare callback */

/*********************************************************************
Set the match mode for ib_cursor_move(). */

void
ib_cursor_set_match_mode(
/*=====================*/
	ib_crsr_t	ib_crsr,	/* in: Cursor instance */
	ib_match_mode_t	match_mode);	/* in: match mode */

/*********************************************************************
Set a column of the tuple. Make a copy using the tuple's heap. */

ib_err_t
ib_col_set_value(
/*=============*/
					/* out: DB_SUCCESS or error code */
	ib_tpl_t	ib_tpl,		/* in: tuple instance */
	ib_ulint_t	col_no,		/* in: column index in tuple */
	const void*	src,		/* in: data value */
	ib_ulint_t	len);		/* in: data value len */

/*********************************************************************
Get the size of the data available in the column the tuple. */

ib_err_t
ib_col_get_len(
/*===========*/
					/* out: bytes avail or IB_SQL_NULL */
	ib_tpl_t	ib_tpl,		/* in: tuple instance */
	ib_ulint_t	i);		/* in: column index in tuple */

/*********************************************************************
Copy a column value from the tuple. */

ib_ulint_t
ib_col_copy_value(
/*==============*/
					/* out: bytes copied or IB_SQL_NULL */
	ib_tpl_t	ib_tpl,		/* in: tuple instance */
	ib_ulint_t	i,		/* in: column index in tuple */
	void*		dst,		/* out: copied data value */
	ib_ulint_t	len);		/* in: max data value len to copy */

/*****************************************************************
Read a signed int 8 bit column from an InnoDB tuple. */

ib_err_t
ib_tuple_read_i8(
/*=============*/
	ib_tpl_t	ib_tpl,	        /* in: InnoDB tuple */
	ib_ulint_t	i,	        /* in: column number */
	ib_i8_t*	ival);	        /* out: integer value */

/*****************************************************************
Read an unsigned int 8 bit column from an InnoDB tuple. */

ib_err_t
ib_tuple_read_u8(
/*=============*/
	ib_tpl_t	ib_tpl,	        /* in: InnoDB tuple */
	ib_ulint_t	i,	        /* in: column number */
	ib_u8_t*	ival);	        /* out: integer value */

/*****************************************************************
Read a signed int 16 bit column from an InnoDB tuple. */

ib_err_t
ib_tuple_read_i16(
/*==============*/
	ib_tpl_t	ib_tpl,		/* in: InnoDB tuple */
	ib_ulint_t	i,		/* in: column number */
	ib_i16_t*	ival);		/* out: integer value */

/*****************************************************************
Read an unsigned int 16 bit column from an InnoDB tuple. */

ib_err_t
ib_tuple_read_u16(
/*==============*/
	ib_tpl_t	ib_tpl,		/* in: InnoDB tuple */
	ib_ulint_t	i,		/* in: column number */
	ib_u16_t*	ival);		/* out: integer value */

/*****************************************************************
Read a signed int 32 bit column from an InnoDB tuple. */

ib_err_t
ib_tuple_read_i32(
/*==============*/
	ib_tpl_t	ib_tpl,		/* in: InnoDB tuple */
	ib_ulint_t	i,		/* in: column number */
	ib_i32_t*	ival);		/* out: integer value */

/*****************************************************************
Read an unsigned int 32 bit column from an InnoDB tuple. */

ib_err_t
ib_tuple_read_u32(
/*==============*/
	ib_tpl_t	ib_tpl,		/* in: InnoDB tuple */
	ib_ulint_t	i,		/* in: column number */
	ib_u32_t*	ival);		/* out: integer value */

/*****************************************************************
Read a signed int 64 bit column from an InnoDB tuple. */

ib_err_t
ib_tuple_read_i64(
/*==============*/
	ib_tpl_t	ib_tpl,		/* in: InnoDB tuple */
	ib_ulint_t	i,		/* in: column number */
	ib_i64_t*	ival);		/* out: integer value */

/*****************************************************************
Read an unsigned int 64 bit column from an InnoDB tuple. */

ib_err_t
ib_tuple_read_u64(
/*==============*/
	ib_tpl_t	ib_tpl,		/* in: InnoDB tuple */
	ib_ulint_t	i,		/* in: column number */
	ib_u64_t*	ival);		/* out: integer value */

/*********************************************************************
Get a column value pointer from the tuple. */

const void*
ib_col_get_value(
/*=============*/
					/* out: NULL or pointer to buffer */
	ib_tpl_t	ib_tpl,		/* in: tuple instance */
	ib_ulint_t	i);		/* in: column index in tuple */

/*********************************************************************
Get a column type, length and attributes from the tuple. */

ib_ulint_t
ib_col_get_meta(
/*============*/
					/* out: len of column data */
	ib_tpl_t	ib_tpl,		/* in: tuple instance */
	ib_ulint_t	i,		/* in: column index in tuple */
	ib_col_meta_t*	ib_col_meta);	/* out: column meta data */

/*********************************************************************
"Clear" or reset an InnoDB tuple. We free the heap and recreate the tuple. */

ib_tpl_t
ib_tuple_clear(
/*============*/
					/* out: new tuple, or NULL */
	ib_tpl_t	ib_tpl);	/* in,own: tuple (will be freed) */

/*********************************************************************
Create a new cluster key search tuple and copy the contents of  the
secondary index key tuple columns that refer to the cluster index record
to the cluster key. It does a deep copy of the column data. */

ib_err_t
ib_tuple_get_cluster_key(
/*=====================*/
					/* out: DB_SUCCESS or error code */
	ib_crsr_t	ib_crsr,	/* in: secondary index cursor */
	ib_tpl_t*	ib_dst_tpl,	/* out,own: destination tuple */
	const ib_tpl_t	ib_src_tpl);	/* in: source tuple */

/*********************************************************************
Copy the contents of  source tuple to destination tuple. The tuples
must be of the same type and belong to the same table/index. */

ib_err_t
ib_tuple_copy(
/*==========*/
					/* out: DB_SUCCESS or error code */
	ib_tpl_t	ib_dst_tpl,	/* in: destination tuple */
	const ib_tpl_t	ib_src_tpl);	/* in: source tuple */

/*********************************************************************
Create an InnoDB tuple used for index/table search. */

ib_tpl_t
ib_sec_search_tuple_create(
/*=======================*/
					/* out, own: Tuple for current index */
	ib_crsr_t	ib_crsr);	/* in: Cursor instance */

/*********************************************************************
Create an InnoDB tuple used for index/table search. */

ib_tpl_t
ib_sec_read_tuple_create(
/*=====================*/
					/* out,own: Tuple for current index */
	ib_crsr_t	ib_crsr);	/* in: Cursor instance */

/*********************************************************************
Create an InnoDB tuple used for table key operations. */

ib_tpl_t
ib_clust_search_tuple_create(
/*=========================*/
					/* out,own: Tuple for current table */
	ib_crsr_t	ib_crsr);	/* in: Cursor instance */

/*********************************************************************
Create an InnoDB tuple for table row operations. */

ib_tpl_t
ib_clust_read_tuple_create(
/*=======================*/
					/* out,own: Tuple for current table */
	ib_crsr_t	ib_crsr);	/* in: Cursor instance */

/*********************************************************************
Return the number of user columns in the tuple definition. */

ib_ulint_t
ib_tuple_get_n_user_cols(
/*=====================*/
					/* out: number of user columns */
	const ib_tpl_t	ib_tpl);	/* in: Tuple for current table */

/*********************************************************************
Return the number of columns in the tuple definition. */

ib_ulint_t
ib_tuple_get_n_cols(
/*================*/
					/* out: number of columns */
	const ib_tpl_t	ib_tpl);	/* in: Tuple for table/index */

/*********************************************************************
Destroy an InnoDB tuple. */

void
ib_tuple_delete(
/*============*/
	ib_tpl_t	ib_tpl);	/* in,own: Tuple instance to delete */

/*********************************************************************
Truncate a table. The cursor handle will be closed and set to NULL
on success. */

ib_err_t
ib_cursor_truncate(
/*===============*/
					/* out: DB_SUCCESS or error code */
	ib_crsr_t*	ib_crsr,	/* in/out: cursor for table
					to truncate */
	ib_id_t*	table_id);	/* out: InnoDB new table id */

/*********************************************************************
Truncate a table. */

ib_err_t
ib_table_truncate(
/*==============*/
					/* out: DB_SUCCESS or error code */
	const char*	table_name,	/* in: table name */
	ib_id_t*	table_id);	/* out: new table id */

/*********************************************************************
Get a table id. */

ib_err_t
ib_table_get_id(
/*============*/
					/* out: DB_SUCCESS if found */
	const char*	table_name,	/* in: table to find */
	ib_id_t*	table_id);	/* out: table id if found */

/*********************************************************************
Get an index id. */

ib_err_t
ib_index_get_id(
/*============*/
					/* out: DB_SUCCESS if found */
	const char*	table_name,	/* in: find index for this table */
	const char*	index_name,	/* in: index to find */
	ib_id_t*	index_id);	/* out: index id if found */

/*************************************************************************
Create a database if it doesn't exist. */

ib_bool_t
ib_database_create(
/*===============*/
					/* out: IB_TRUE on success */
	const char*	dbname);	/* in: database name to create */

/*************************************************************************
Drop a database if it exists. The database must be empty. */

ib_err_t
ib_database_drop(
/*=============*/
					/* out: DB_SUCCESS or error code */
	const char*	dbname);	/* in: database name to drop */

/*********************************************************************
Check if cursor is positioned. */

ib_bool_t
ib_cursor_is_positioned(
/*====================*/
					/* out: IB_TRUE if positioned */
	const ib_crsr_t	ib_crsr);	/* in: InnoDB cursor instance */

/*********************************************************************
Latches the data dictionary in shared mode. */

ib_err_t
ib_schema_lock_shared(
/*==================*/
					/* out: DB_SUCCESS or error code */
	ib_trx_t	ib_trx);	/* in/out: transaction */

/*********************************************************************
Latches the data dictionary in exclusive mode. */

ib_err_t
ib_schema_lock_exclusive(
/*======================*/
					/* out: DB_SUCCESS or error code */
	ib_trx_t	ib_trx);	/* in/out: transaction */

/*********************************************************************
Checks if the data dictionary is latched in exclusive mode. */

ib_bool_t
ib_schema_lock_is_exclusive(
/*========================*/
					/* out: TRUE if exclusive latch */
	const ib_trx_t	ib_trx);	/* in: transaction */

/*********************************************************************
Unlocks the data dictionary. */

ib_err_t
ib_schema_unlock(
/*=============*/
					/* out: DB_SUCCESS or error code */
	ib_trx_t	ib_trx);	/* in/out: transaction */

/*********************************************************************
Lock an InnoDB cursor/table. */

ib_err_t
ib_cursor_lock(
/*===========*/
					/* out: DB_SUCCESS or error code */
	ib_crsr_t	ib_crsr,	/* in/out: InnoDB cursor */
	ib_lck_mode_t	ib_lck_mode);	/* in: InnoDB lock mode */

/*********************************************************************
Set the Lock an InnoDB table using the table id. */

ib_err_t
ib_table_lock(
/*===========*/
					/* out: DB_SUCCESS or error code */
	ib_trx_t	ib_trx,		/* in/out: transaction */
	ib_id_t		table_id,	/* in: table id */
	ib_lck_mode_t	ib_lck_mode);	/* in: InnoDB lock mode */

/*********************************************************************
Set the Lock mode of the cursor. */

ib_err_t
ib_cursor_set_lock_mode(
/*====================*/
					/* out: DB_SUCCESS or error code */
	ib_crsr_t	ib_crsr,	/* in/out: InnoDB cursor */
	ib_lck_mode_t	ib_lck_mode);	/* in: InnoDB lock mode */

/*********************************************************************
Set need to access clustered index record. */

void
ib_cursor_set_cluster_access(
/*=========================*/
	ib_crsr_t	ib_crsr);	/* in/out: InnoDB cursor */

/*********************************************************************
Check if table exists in InnoDB data dictionary. */

ib_err_t
ib_check_if_table_exists(
/*=====================*/
					/* out: DB_SUCCESS or
					DB_TABLE_NOT_FOUND */
	const char*	table_name,	/* in: table name to lookup */
	ib_id_t*	table_id);	/* out: table id if table found */

/*********************************************************************
Read a table's schema using the visitor pattern. It will make the
following sequence of calls:

	visitor->table()
	visitor->table_col() for each user column
	visitor->index() for each user index
	visitor->index_col() for each column in user index

It will stop if any of the above functions returns a non-zero value.
The caller must have an exclusive lock on the InnoDB data dictionary */

ib_err_t
ib_table_schema_visit(
/*==================*/
					/* out: DB_SUCCESS or DB_ERROR */
	ib_trx_t			ib_trx,
					/* in: transaction that
					owns the schema lock */
	const char*		name,	/* in: table name to read */
	const ib_schema_visitor_t*	/* in: visitor functions */
				visitor,/* to invoke on each definition */
	void*			arg);	/* Argument passed to the
					visitor functions. */

/*********************************************************************
List all the tables in the InnoDB's data dictionary. It will abort
if visitor returns a non-zero value.

It will call the function:
	visitor.tables(arg, const char* name, int name_len);

The function will abort if visitor.tables() returns non-zero. */

ib_err_t
ib_schema_tables_iterate(
/*=====================*/
	ib_trx_t		ib_trx,	/* in: transaction that
					owns the schema lock */
	ib_schema_visitor_table_all_t
				visitor,/* in: visitor function */
	void*			arg);	/* in: argument passed to the visitor
					function */

/*************************************************************************
Get the type of a configuration variable. Returns DB_SUCCESS if the
variable with name "name" was found and "type" was set. */

ib_err_t
ib_cfg_var_get_type(
/*================*/
					/* out: DB_SUCCESS if successful */
	const char*	name,		/* in: variable name */
	ib_cfg_type_t*	type);		/* out: variable type */

/*************************************************************************
Set a configuration variable. The second argument's type depends on the
type of the variable with the given "name". Returns DB_SUCCESS if the
variable with name "name" was found and if its value was set. */

ib_err_t
ib_cfg_set(
/*=======*/
					/* out: DB_SUCCESS if set */
	const char*	name,		/* in: variable name */
	...);				/* in: variable value */

/*************************************************************************
Get the value of a configuration variable. The type of the returned value
depends on the type of the configuration variable. DB_SUCCESS is returned
if the variable with name "name" was found and "value" was set. */

ib_err_t
ib_cfg_get(
/*=======*/
					/* out: DB_SUCCESS if retrieved
					successfully */
	const char*	name,		/* in: variable name */
	void*		value);		/* out: place to store the retrieved
					value */

/***********************************************************************
Creates a named savepoint. If the transaction is not yet started, starts it.
If there is already a savepoint of the same name, this call erases that old
savepoint and replaces it with a new. Savepoints are deleted in a transaction
commit or rollback. */

void
ib_savepoint_take(
/*===============*/
	ib_trx_t	ib_trx,		/* in: transaction */
	const void*	name,		/* in: savepoint name */
	ib_ulint_t	name_len);	/* in: length of name in bytes */

/***********************************************************************
Releases only the named savepoint. Savepoints which were set after this
savepoint are left as is. */

ib_err_t
ib_savepoint_release(
/*=================*/
					/* out: if no savepoint of the name
					found then DB_NO_SAVEPOINT,
					otherwise DB_SUCCESS */
	ib_trx_t	ib_trx,		/* in: transaction handle */
	const void*	name,		/* in: savepoint name */
	ib_ulint_t	name_len);	/* in: length of name in bytes */

/***********************************************************************
Rolls back a transaction back to a named savepoint. Modifications after the
savepoint are undone but InnoDB does NOT release the corresponding locks
which are stored in memory. If a lock is 'implicit', that is, a new inserted
row holds a lock where the lock information is carried by the trx id stored in
the row, these locks are naturally released in the rollback. Savepoints which
were set after this savepoint are deleted. If name equals NULL then all the
savepoints are rolled back. */

ib_err_t
ib_savepoint_rollback(
/*==================*/
					/* out: if no savepoint of the name
					found then DB_NO_SAVEPOINT,
					otherwise DB_SUCCESS */
	ib_trx_t	ib_trx,		/* in: transaction handle */
	const void*	name,		/* in: savepoint name  can be NULL */
	ib_ulint_t	name_len);	/* in: length of name in bytes */

/*********************************************************************
Write an integer value to a column. Integers are stored in big-endian
format and will need to be converted from the host format. */

ib_err_t
ib_tuple_write_i8(
/*==============*/
					/* out: DB_SUCESS or error */
	ib_tpl_t	ib_tpl,		/* upd: tuple to write to */
	int		col_no,		/* in: column number */
	ib_i8_t		val);		/* in: value to write */

/*********************************************************************
Write an integer value to a column. Integers are stored in big-endian
format and will need to be converted from the host format. */

ib_err_t
ib_tuple_write_i16(
/*=================*/
					/* out: DB_SUCESS or error */
	ib_tpl_t	ib_tpl,		/* upd: tuple to write to */
	int		col_no,		/* in: column number */
	ib_i16_t	val);		/* in: value to write */

/*********************************************************************
Write an integer value to a column. Integers are stored in big-endian
format and will need to be converted from the host format. */

ib_err_t
ib_tuple_write_i32(
/*===============*/
					/* out: DB_SUCESS or error */
	ib_tpl_t	ib_tpl,		/* upd: tuple to write to */
	int		col_no,		/* in: column number */
	ib_i32_t	val);		/* in: value to write */

/*********************************************************************
Write an integer value to a column. Integers are stored in big-endian
format and will need to be converted from the host format. */

ib_err_t
ib_tuple_write_i64(
/*===============*/
					/* out: DB_SUCESS or error */
	ib_tpl_t	ib_tpl,		/* upd: tuple to write to */
	int		col_no,		/* in: column number */
	ib_i64_t	val);		/* in: value to write */

/*********************************************************************
Write an integer value to a column. Integers are stored in big-endian
format and will need to be converted from the host format. */

ib_err_t
ib_tuple_write_u8(
/*==============*/
					/* out: DB_SUCESS or error */
	ib_tpl_t	ib_tpl,		/* upd: tuple to write to */
	int		col_no,		/* in: column number */
	ib_u8_t		val);		/* in: value to write */

/*********************************************************************
Write an integer value to a column. Integers are stored in big-endian
format and will need to be converted from the host format. */

ib_err_t
ib_tuple_write_u16(
/*===============*/
					/* out: DB_SUCESS or error */
	ib_tpl_t	ib_tpl,		/* upd: tuple to write to */
	int		col_no,		/* in: column number */
	ib_u16_t	val);		/* in: value to write */

/*********************************************************************
Write an integer value to a column. Integers are stored in big-endian
format and will need to be converted from the host format. */

ib_err_t
ib_tuple_write_u32(
/*=================*/
					/* out: DB_SUCESS or error */
	ib_tpl_t	ib_tpl,		/* upd: tuple to write to */
	int		col_no,		/* in: column number */
	ib_u32_t	val);		/* in: value to write */

/*********************************************************************
Write an integer value to a column. Integers are stored in big-endian
format and will need to be converted from the host format. */

ib_err_t
ib_tuple_write_u64(
/*===============*/
					/* out: DB_SUCESS or error */
	ib_tpl_t	ib_tpl,		/* upd: tuple to write to */
	int		col_no,		/* in: column number */
	ib_u64_t	val);		/* in: value to write */

/*********************************************************************
Inform the cursor that it's the start of an SQL statement. */

void
ib_cursor_stmt_begin(
/*=================*/
	ib_crsr_t	ib_crsr);

/*********************************************************************
Write a double value to a column. */

ib_err_t
ib_tuple_write_double(
/*==================*/
					/* out: DB_SUCCESS or error */
	ib_tpl_t	ib_tpl,		/* upd: tuple to write to */
	int		col_no,		/* in: column number */
	double		val);		/* in: value to write */

/*****************************************************************
Read a double column value from an InnoDB tuple. */

ib_err_t
ib_tuple_read_double(
/*=================*/
					/* out: DB_SUCCESS or error */
	ib_tpl_t	ib_tpl,		/* in: InnoDB tuple */
	ib_ulint_t	col_no,		/* in: column number */
	double*		dval);		/* out: double value */

/*********************************************************************
Write a float value to a column. */

ib_err_t
ib_tuple_write_float(
/*=================*/
					/* out: DB_SUCCESS or error */
	ib_tpl_t	ib_tpl,		/* upd: tuple to write to */
	int		col_no,		/* in: column number */
	float		val);		/* in: value to write */

/*****************************************************************
Read a float value from an InnoDB tuple. */

ib_err_t
ib_tuple_read_float(
/*================*/
					/* out: DB_SUCCESS or error */
	ib_tpl_t	ib_tpl,		/* in: InnoDB tuple */
	ib_ulint_t	col_no,		/* in: column number */
	float*		fval);		/* out: float value */

/*****************************************************************
Set the message logging function. */

void
ib_logger_set(
/*==========*/
	ib_msg_log_t	ib_msg_log,	/* in: the message logging function */
	ib_msg_stream_t	ib_msg_stream);	/* in: the message stream, this is
					the first argument to the logging
					function */

/*****************************************************************
Convert an error number to a human readable text message. The
returned string is static and should not be freed or modified. */

const char*
ib_strerror(
/*========*/
				/* out: string, describing the error */
	ib_err_t	num);	/* in: error number */

/* API_END_INCLUDE */
#include <stdarg.h>

/*************************************************************************
Declare private functions that should not be visible in the public API
below, outside of API_BEGIN_INCLUDE/API_END_INCLUDE.
*************************************************************************/

/*************************************************************************
Execute arbitrary SQL using InnoDB's internal parser. The statement
is executed in a new transaction. Table name parameters must be prefixed
with a '$' symbol and variables with ':' */

ib_err_t
ib_exec_sql(
/*========*/
					/* out: DB_SUCCESS or error code */
	const char*     sql,            /* in: sql to execute */
	ib_ulint_t	n_args,         /* in: no. of args */
	...);

/*************************************************************************
Execute arbitrary SQL using InnoDB's internal parser. The statement
is executed in a background transaction. It will lock the data
dictionary lock for the duration of the query. */

ib_err_t
ib_exec_ddl_sql(
/*============*/
					/* out: DB_SUCCESS or error code */
	const char*	sql,		/* in: sql to execute */
	ib_ulint_t	n_args,		/* in: no. of args */
	...);

/*************************************************************************
Initialize the config system. */

ib_err_t
ib_cfg_init(void);
/*==============*/
	/* out: DB_SUCCESS or error code */

/*************************************************************************
Shutdown the config system. */

ib_err_t
ib_cfg_shutdown(void);
/*==================*/
	/* out: DB_SUCCESS or error code */

/*************************************************************************
Set a configuration variable. "ap" must contain one argument whose type
depends on the type of the variable with the given "name". Returns
DB_SUCCESS if the variable with name "name" was found and if its value
was set. */

ib_err_t
ib_cfg_set_ap(
/*==========*/
					/* out: DB_SUCCESS if set */
	const char*	name,		/* in: variable name */
	va_list		ap);		/* in: variable value */

#endif /* INNOBASE_API_H */
