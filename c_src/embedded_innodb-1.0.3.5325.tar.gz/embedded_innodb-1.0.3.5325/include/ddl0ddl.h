/******************************************************
Contains InnoDB DDL operations. 

(c) 2008 Oracle Corpn/Innobase Oy

Created 12 Oct 2008
*******************************************************/

#ifndef ddl0ddl_h
#define ddl0ddl_h

#include "univ.i"
#include "trx0types.h"
#include "dict0types.h"

/*************************************************************************
Get the background drop list length. NOTE: the caller must own the kernel
mutex! */
UNIV_INTERN
ulint
ddl_get_background_drop_list_len_low(void);
/*======================================*/
					/* out: how many tables in list */

/*************************************************************************
Creates a table, if the name of the table ends in one of "innodb_monitor",
"innodb_lock_monitor", "innodb_tablespace_monitor", "innodb_table_monitor",
then this will also start the printing of monitor output by the master
thread. If the table name ends in "innodb_mem_validate", InnoDB will
try to invoke mem_validate(). */
UNIV_INTERN
ulint
ddl_create_table(
/*=============*/
					/* out: error code or DB_SUCCESS */
	dict_table_t*	table,		/* in: table definition */
	trx_t*		trx);		/* in: transaction handle */

/*************************************************************************
Does an index creation operation. TODO: currently failure to create an
index results in dropping the whole table! This is no problem currently
as all indexes must be created at the same time as the table. */
UNIV_INTERN
ulint
ddl_create_index(
/*=============*/
					/* out: error number or DB_SUCCESS */
	dict_index_t*	index,		/* in: index definition */
	trx_t*		trx);		/* in: transaction handle */

/*************************************************************************
Drops a table but does not commit the transaction.  If the
name of the dropped table ends in one of "innodb_monitor",
"innodb_lock_monitor", "innodb_tablespace_monitor",
"innodb_table_monitor", then this will also stop the printing of
monitor output by the master thread. */
UNIV_INTERN
ulint
ddl_drop_table(
/*===========*/
					/* out: error code or DB_SUCCESS */
	const char*	name,		/* in: table name */
	trx_t*		trx,		/* in: transaction handle */
	ibool		drop_db);	/* in: TRUE=dropping whole database */

/*************************************************************************
Drops an index. */
UNIV_INTERN
ulint
ddl_drop_index(
/*===========*/
					/* out: error code or DB_SUCCESS */
	dict_table_t*	table,		/* in: table instance */
	dict_index_t*	index,		/* in: id of index to drop */
	trx_t*		trx);		/* in: transaction handle */

/*************************************************************************
The master thread in srv0srv.c calls this regularly to drop tables which
we must drop in background after queries to them have ended. Such lazy
dropping of tables is needed in ALTER TABLE on Unix. */
UNIV_INTERN
ulint
ddl_drop_tables_in_background(void);
/*===============================*/
					/* out: how many tables dropped
					+ remaining tables in list */

/*************************************************************************
Truncates a table */
UNIV_INTERN
enum db_err
ddl_truncate_table(
/*===============*/
					/* out: error code or DB_SUCCESS */
	dict_table_t*	table,		/* in: table handle */
	trx_t*		trx);		/* in: transaction handle */
/*************************************************************************
Renames a table. */
UNIV_INTERN
ulint
ddl_rename_table(
/*=============*/
					/* out: error code or DB_SUCCESS */
	const char*	old_name,	/* in: old table name */
	const char*	new_name,	/* in: new table name */
	trx_t*		trx);		/* in: transaction handle */

/*************************************************************************
Renames an index. */
UNIV_INTERN
ulint
ddl_rename_index(
/*=============*/
					/* out: error code or DB_SUCCESS */
	const char*	table_name,	/* in: table that owns the index */
	const char*	old_name,	/* in: old table name */
	const char*	new_name,	/* in: new table name */
	trx_t*		trx);		/* in: transaction handle */

/*************************************************************************
Drops a database. */
UNIV_INTERN
enum db_err
ddl_drop_database(
/*==============*/
					/* out: error code or DB_SUCCESS */
	const char*	name,		/* in: database name which ends
					in '/' */
	trx_t*		trx);		/* in: transaction handle */
#endif /* ddl0ddl_h */
