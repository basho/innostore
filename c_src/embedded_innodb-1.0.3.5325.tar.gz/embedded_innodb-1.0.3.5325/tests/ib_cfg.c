#include <stdio.h>
#include <assert.h>

#include "innodb.h"

void
get_all()
{
	const char*	var_names[] = {
		"adaptive_hash_index",
		"additional_mem_pool_size",
		"autoextend_increment",
		"buffer_pool_size",
		"checksums",
		"commit_concurrency",
		"concurrency_tickets",
		"data_file_path",
		"data_home_dir",
		"doublewrite",
		"fast_shutdown",
		"file_format",
		"file_io_threads",
		"file_per_table",
		"flush_log_at_trx_commit",
		"flush_method",
		"force_recovery",
		"lock_wait_timeout",
		"log_buffer_size",
		"log_file_size",
		"log_files_in_group",
		"log_group_home_dir",
		"max_dirty_pages_pct",
		"max_purge_lag",
		"mirrored_log_groups",
		"open_files",
		"pre_rollback_hook",
		"print_verbose_log",
		"rollback_on_timeout",
		"stats_sample_pages",
		"status_file",
		"sync_spin_loops",
		"thread_concurrency",
		"thread_sleep_delay",
		"version",
	};
	ib_bool_t	ret;
	void*		val;
	int		i;

	for (i = 0; i < sizeof(var_names) / sizeof(var_names[0]); i++) {
		ret = ib_cfg_get(var_names[i], &val);
		assert(ret);
	}
}

int
main(int argc, char** argv)
{
	ib_bool_t	ret;

	ib_init();

	get_all();

	ret = ib_cfg_set("flush_method", "fdatasync");
	assert(ret);

	ret = ib_cfg_set("open_files", 123);
	assert(ret);

	get_all();

	ib_shutdown();

	return(0);
}
